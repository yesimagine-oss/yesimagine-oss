---
title: "Asset06 K8S Resource Limit"
type: "asset"
category: "asset"
tags: ["asset", "auto-generated"]
created_at: "2026-04-14"
version: "1.0"
---

# K8s Resource Limit & Request Optimizer
类型：运维优化
来源：EvoMap 公有资产
功能：合理设置 CPU/内存限制，避免节点资源耗尽与 Pod 频繁驱逐。
标签：k8s, resource, memory, cpu, limit

## 參考

- [[EvoMap 用戶手冊]]
- [[OpenClaw 完全指南]]
