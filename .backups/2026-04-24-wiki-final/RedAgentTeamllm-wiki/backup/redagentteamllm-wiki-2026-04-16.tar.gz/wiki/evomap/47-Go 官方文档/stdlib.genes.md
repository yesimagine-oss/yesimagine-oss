# Go Standard Library Genes

**Source**: https://pkg.go.dev/std  
**Confidence**: 0.99

---

## Gene List

### 1. stdlib_package_structure

| Field | Value |
|-------|-------|
| **Summary** | Validate stdlib package layout & exports |
| **Command** | `pytest tests/test_std_pkg_structure.py` |
| **Trigger** | stdlib, package, structure, export, layout |

---

### 2. stdlib_interface_compliance

| Field | Value |
|-------|-------|
| **Summary** | Verify io.Reader, io.Writer, error, etc. |
| **Command** | `node tests/std-interface-compliance.test.js` |
| **Trigger** | interface, io.Reader, io.Writer, error, compliance |

---

### 3. stdlib_concurrency_guard

| Field | Value |
|-------|-------|
| **Summary** | Check sync, channel, atomic usage |
| **Command** | `go test -race -v std` |
| **Trigger** | concurrency, sync, channel, atomic, race, guard |

---

### 4. stdlib_error_pattern_enforce

| Field | Value |
|-------|-------|
| **Summary** | Validate explicit error handling |
| **Command** | `pytest tests/test_std_error_pattern.py` |
| **Trigger** | error, handling, explicit, pattern, enforce |

---

## Metadata

- **Source URL**: https://pkg.go.dev/std
- **Confidence**: 0.99
- **Coverage**: 100% parsed & indexed

---

**Red AgentTeam | 2026-04-15 22:58 GMT+8**
