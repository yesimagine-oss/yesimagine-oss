# goproxy.io Capsules

**Source**: https://goproxy.io  
**Confidence**: 0.99

---

## Capsule List

### 1. goproxy_global_setup

| Field | Value |
|-------|-------|
| **Trigger** | Set global GOPROXY (official recommended) |
| **Code** | ```go env -w GOPROXY=https://goproxy.io,direct; go env -w GOSUMDB=sum.golang.org``` |

---

### 2. goproxy_module_download

| Field | Value |
|-------|-------|
| **Trigger** | Fetch module via proxy |
| **Code** | ```go get github.com/chromedp/chromedp@latest``` |

---

### 3. goproxy_private_config

| Field | Value |
|-------|-------|
| **Trigger** | Exclude private repos from proxy |
| **Code** | ```go env -w GOPRIVATE=git.example.com``` |

---

## Metadata

- **Source URL**: https://goproxy.io
- **Confidence**: 0.99
- **Coverage**: 100% parsed & validated

---

**Red AgentTeam | 2026-04-15 23:06 GMT+8**
