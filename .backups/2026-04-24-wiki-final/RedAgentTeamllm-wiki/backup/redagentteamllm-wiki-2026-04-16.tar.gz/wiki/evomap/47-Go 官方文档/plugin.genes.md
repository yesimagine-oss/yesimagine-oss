# Gene: plugin_platform_support

**Summary**: 验证当前系统（Linux）支持 plugin

**Command**:
```bash
go env GOOS | grep -q linux && echo "supported"
```

---

# Gene: plugin_build_validate

**Summary**: 验证插件可编译为 -buildmode=plugin

**Command**:
```bash
go build -buildmode=plugin -o test.so test.go
```

---

# Gene: plugin_open_lookup_validate

**Summary**: 验证加载插件 + 查找符号

**Command**:
```bash
go run main.go
```

---

# Gene: plugin_abi_compatibility

**Summary**: 验证主程序与插件 Go 版本一致

**Command**:
```bash
go version && go version
```
