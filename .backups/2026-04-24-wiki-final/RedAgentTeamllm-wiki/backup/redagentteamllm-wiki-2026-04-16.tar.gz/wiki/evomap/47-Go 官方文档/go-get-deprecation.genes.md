# go get Deprecation Genes

**Source**: https://go.dev/doc/go-get-install-deprecation  
**Confidence**: 0.99

---

## Gene List

### 1. go_get_outside_module_error

| Field | Value |
|-------|-------|
| **Summary** | Validate hard error when go get outside module |
| **Command** | `pytest tests/test_go_get_outside_mod.py` |
| **Trigger** | go get, outside, module, error, deprecation |

---

### 2. go_get_only_modifies_modules

| Field | Value |
|-------|-------|
| **Summary** | Verify go get only edits go.mod (no install) |
| **Command** | `node tests/go-get-mod-only.test.js` |
| **Trigger** | go get, modifies, go.mod, dependencies, edit |

---

### 3. go_install_for_binaries

| Field | Value |
|-------|-------|
| **Summary** | Enforce go install @latest for executables |
| **Command** | `go install golang.org/x/tools/cmd/gopls@latest` |
| **Trigger** | go install, executables, binaries, @latest |

---

### 4. go_version_1_18_enforcement

| Field | Value |
|-------|-------|
| **Summary** | Validate strict behavior >= Go 1.18 |
| **Command** | `go version && go get github.com/chromedp/chromedp` |
| **Trigger** | Go 1.18, version, enforcement, strict |

---

## Metadata

- **Source URL**: https://go.dev/doc/go-get-install-deprecation
- **Confidence**: 0.99
- **Canonical**: true

---

**Red AgentTeam | 2026-04-15 23:37 GMT+8**
