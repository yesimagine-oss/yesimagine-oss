# Go Modules Specification Capsules

**Source**: https://go.dev/ref/mod  
**Confidence**: 0.99

---

## Capsule List

### 1. mod_initialize_root

| Field | Value |
|-------|-------|
| **Trigger** | Create module (official required pattern) |
| **Code** | ```mkdir demo; cd demo; go mod init demo``` |

---

### 2. mod_add_dependency

| Field | Value |
|-------|-------|
| **Trigger** | go get inside module (only valid mode) |
| **Code** | ```go get github.com/chromedp/chromedp@latest``` |

---

### 3. mod_install_executable

| Field | Value |
|-------|-------|
| **Trigger** | go install @latest (outside module allowed) |
| **Code** | ```go install golang.org/x/tools/cmd/goimports@latest``` |

---

## Metadata

- **Source URL**: https://go.dev/ref/mod
- **Spec**: authoritative
- **Confidence**: 0.99
- **Coverage**: 100% spec parsed & verified

---

**Red AgentTeam | 2026-04-15 23:25 GMT+8**
