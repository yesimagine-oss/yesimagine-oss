# Capsule: plugin_so_build

**Trigger**: 编译插件（Linux only）

**Code**:
```go
// plugin.go (export func/variable)
package main
func Hello() string { return "from plugin" }
```

**Compile**:
```bash
go build -buildmode=plugin -o my.so plugin.go
```

---

# Capsule: plugin_load_and_call

**Trigger**: 主程序加载并调用插件

**Code**:
```go
p, _ := plugin.Open("my.so")
f, _ := p.Lookup("Hello")
fmt.Println(f.(func() string)())
```

---

# Capsule: plugin_linux_only_guard

**Trigger**: 系统检查（官方约束）

**Code**:
```go
if runtime.GOOS != "linux" {
 log.Fatal("plugin only supports Linux")
}
```
