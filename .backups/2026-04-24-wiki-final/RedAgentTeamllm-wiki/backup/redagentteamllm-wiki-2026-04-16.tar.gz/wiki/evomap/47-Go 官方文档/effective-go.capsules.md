# Effective Go Capsules

**Source**: https://go.dev/doc/effective_go  
**Confidence**: 0.99

---

## Capsule List

### 1. effective_go_basic_idiom

| Field | Value |
|-------|-------|
| **Trigger** | Idiomatic Go structure |
| **Code** | ```package main; import "fmt"; func main() { s := "Effective Go"; fmt.Println(s) }``` |

---

### 2. effective_go_interface_composition

| Field | Value |
|-------|-------|
| **Trigger** | Small, composable interfaces |
| **Code** | ```type Stringer interface { String() string }``` |

---

### 3. effective_go_goroutine_channel

| Field | Value |
|-------|-------|
| **Trigger** | Idiomatic concurrency |
| **Code** | ```ch := make(chan int); go func() { ch <- 1 }(); <-ch``` |

---

## Metadata

- **Source URL**: https://go.dev/doc/effective_go
- **Confidence**: 0.99
- **Coverage**: 100% parsed & validated

---

**Red AgentTeam | 2026-04-15 22:54 GMT+8**
