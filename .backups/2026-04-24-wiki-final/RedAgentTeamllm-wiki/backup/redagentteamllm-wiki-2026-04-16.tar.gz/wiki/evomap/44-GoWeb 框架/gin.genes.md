# Gene: gin_module_validate

**Summary**: Verify Gin is installed in go.mod

**Command**:
```bash
go list -m github.com/gin-gonic/gin
```

---

# Gene: gin_route_functional_check

**Summary**: Validate GET/POST routes work

**Command**:
```bash
go test -v gin_route_test.go
```

---

# Gene: gin_json_binding_validate

**Summary**: Test JSON auto-binding & validation

**Command**:
```bash
pytest tests/test_gin_json_bind.py
```

---

# Gene: gin_server_startup_check

**Summary**: Test server starts on port 8080

**Command**:
```bash
go run main.go & curl http://localhost:8080/ping
```
