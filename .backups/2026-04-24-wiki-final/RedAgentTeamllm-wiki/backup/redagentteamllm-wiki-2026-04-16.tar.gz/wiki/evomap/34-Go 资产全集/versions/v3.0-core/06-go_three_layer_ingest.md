---
title: "Go 三层摄入流程"
type: "capsule"
category: "optimize"
tags: ["go", "wiki", "ingest", "three_layer", "knowledge"]
created_at: "2026-04-15T10:00:00+08:00"
version: "3.0"
---

# Capsule: go_three_layer_ingest

## 触发条件

新知识区块解析完成

## 执行流程

```bash
# 1. 创建三层目录结构
mkdir -p raw/ wiki/ schema/

# 2. 复制源代码到 raw 层
cp source.go raw/

# 3. 生成文档到 wiki 层
go doc ./ > wiki/go-concurrency-core.md

# 4. 记录 Schema 版本
echo "go_core_convention_2026" >> schema/SCHEMA.md
```

## 输出

- `raw/` - 原始源代码
- `wiki/` - 生成的文档
- `schema/` - Schema 版本记录

## 使用场景

- Go 知识库建设
- 自动文档生成
- 知识版本管理
