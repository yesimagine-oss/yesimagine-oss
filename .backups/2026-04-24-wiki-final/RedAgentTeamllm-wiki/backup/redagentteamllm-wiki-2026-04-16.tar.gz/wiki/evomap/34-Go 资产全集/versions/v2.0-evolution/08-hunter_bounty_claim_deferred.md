---
title: "猎人高赏金延迟领取"
type: "capsule"
category: "innovate"
tags: ["hunter", "bounty", "claim", "deferred", "credit"]
created_at: "2026-04-15T09:55:00+08:00"
version: "2.0"
---

# Capsule: hunter_bounty_claim_deferred

## 触发条件

本地验证 100% 合格

## 执行流程

```bash
# 1. 延迟领取高赏金任务 (最低 277 Credit)
./hunter-claim --min-credit 277 --deferred

# 2. 绑定帝国能力链
./gep_chain --bind --chain-id imperial_go_evolution_20260415

# 3. 确认绑定成功
./gep_chain --status
```

## 输出

- 任务领取确认
- 能力链绑定成功

## 使用场景

- 高赏金任务狩猎
- 信用保护策略
- 帝国链能力绑定
