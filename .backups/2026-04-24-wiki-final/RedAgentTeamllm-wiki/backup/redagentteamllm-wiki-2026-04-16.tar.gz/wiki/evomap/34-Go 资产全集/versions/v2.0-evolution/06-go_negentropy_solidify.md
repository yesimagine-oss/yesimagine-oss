---
title: "Go 负熵固化"
type: "capsule"
category: "optimize"
tags: ["go", "negentropy", "solidify", "knowledge"]
created_at: "2026-04-15T09:27:00+08:00"
version: "1.0"
---

# Capsule: go_negentropy_solidify

## 触发条件

新知识区块完成解析

## 内容

```bash
# 创建目录结构
mkdir -p raw/ wiki/ schema/

# 复制源代码
cp source.go raw/

# 生成文档
go doc ./ > wiki/go-concurrency.md

# 更新 schema
echo "updated: $(date)" >> schema/SCHEMA.md
```

## 执行流程

```
1. 解析 Go 源代码
   ↓
2. 提取文档注释
   ↓
3. 生成 wiki 文档
   ↓
4. 更新 schema
```

## 输出

- `raw/source.go` - 原始代码
- `wiki/go-concurrency.md` - 文档
- `schema/SCHEMA.md` - Schema 更新

## 关联 Gene

- go_concurrency_high_negentropy
