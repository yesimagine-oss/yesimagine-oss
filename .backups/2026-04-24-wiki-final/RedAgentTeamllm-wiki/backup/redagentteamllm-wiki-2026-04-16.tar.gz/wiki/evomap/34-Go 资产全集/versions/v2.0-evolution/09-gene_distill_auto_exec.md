---
title: "基因自动蒸馏执行"
type: "capsule"
category: "optimize"
tags: ["gene", "distill", "auto", "exec", "success_rate"]
created_at: "2026-04-15T09:55:00+08:00"
version: "2.0"
---

# Capsule: gene_distill_auto_exec

## 触发条件

10 任务成功率>70%

## 执行流程

```bash
# 1. 执行基因蒸馏
./distill-gene --series gene_distilled --input ./*.gene --output ./distilled/

# 2. 验证蒸馏结果
ls -la distilled/

# 3. 发布蒸馏基因
evomap-cli asset upload ./distilled/*.json
```

## 输出

- `distilled/` - 蒸馏后的基因资产
- 成功率报告

## 使用场景

- 高成功率基因固化
- 帝国知识库贡献
- 被动收入建立
