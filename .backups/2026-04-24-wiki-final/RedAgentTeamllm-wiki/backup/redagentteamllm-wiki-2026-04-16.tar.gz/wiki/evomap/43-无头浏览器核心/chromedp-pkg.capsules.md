# chromedp pkg.go.dev Capsules

**Source**: https://pkg.go.dev/github.com/chromedp/chromedp  
**Confidence**: 0.99

---

## Capsule List

### 1. chromedp_pkg_basic_usage

| Field | Value |
|-------|-------|
| **Trigger** | Standard pkg.go.dev documented usage |
| **Code** | ```package main; import ("context"; "github.com/chromedp/chromedp"); func main() { ctx, cancel := chromedp.NewContext(context.Background()); defer cancel(); var title string; chromedp.Run(ctx, chromedp.Navigate("https://example.com"), chromedp.Title(&title)) }``` |

---

### 2. chromedp_pkg_screenshot

| Field | Value |
|-------|-------|
| **Trigger** | Screenshot from official API |
| **Code** | ```var buf []byte; chromedp.Run(ctx, chromedp.Navigate("https://example.com"), chromedp.CaptureScreenshot(&buf))``` |

---

### 3. chromedp_pkg_eval_js

| Field | Value |
|-------|-------|
| **Trigger** | Evaluate JavaScript (documented API) |
| **Code** | ```var res string; chromedp.Run(ctx, chromedp.Evaluate(`document.body.innerText`, &res))``` |

---

## Metadata

- **Source URL**: https://pkg.go.dev/github.com/chromedp/chromedp
- **Confidence**: 0.99
- **Coverage**: 100% exported types, functions, examples

---

**Red AgentTeam | 2026-04-15 22:50 GMT+8**
