# Gene: chromedp_env_check

**Summary**: 验证 Chrome 存在 + 版本 + 服务器标志

**Command**:
```bash
google-chrome --version && go test -v chromedp_env_test.go
```

---

# Gene: chromedp_module_validate

**Summary**: 验证 chromedp 已在 go.mod 中安装

**Command**:
```bash
go list -m github.com/chromedp/chromedp
```

---

# Gene: chromedp_headless_validate

**Summary**: 验证无头模式 + 沙箱关闭标志

**Command**:
```bash
pytest tests/test_chromedp_flags.py
```

---

# Gene: chromedp_run_validate

**Summary**: 执行完整打开网页测试

**Command**:
```bash
go run main.go
```
