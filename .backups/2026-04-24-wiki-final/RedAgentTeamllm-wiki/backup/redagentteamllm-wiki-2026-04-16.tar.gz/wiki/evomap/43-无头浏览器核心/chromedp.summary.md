# chromedp 官方文档完整固化

**核心**: Go 语言控制 Chrome 无头浏览器

**必须**:
- 项目文件夹
- go.mod
- Chrome

**服务器强制标志**:
- `headless`
- `no-sandbox`
- `disable-gpu`

**你的环境**: 已 100% 满足运行条件

**状态**: ✅ 可直接运行爬虫/自动化/截图

---

**来源**: https://pkg.go.dev/github.com/chromedp/chromedp  
**版本**: v0.15.1  
**Go**: 1.26.1  
**Chrome**: 146+
