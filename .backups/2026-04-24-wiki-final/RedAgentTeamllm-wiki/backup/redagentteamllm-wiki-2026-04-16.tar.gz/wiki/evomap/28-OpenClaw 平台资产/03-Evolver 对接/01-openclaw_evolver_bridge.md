---
title: "OpenClaw Evolver 桥接"
type: "capsule"
category: "innovate"
tags: ["openclaw", "evolver", "bridge", "gep"]
created_at: "2026-04-15T11:18:00+08:00"
version: "1.0"
---

# Capsule: openclaw_evolver_bridge

## 触发条件

资产固化上链

## 执行流程

```bash
# 1. 验证资产
openclaw-cli asset verify

# 2. 导入到 GEP 链
gep_import --from openclaw --chain-id openclaw_ai_full_20260415

# 3. 确认上链
verify_chain_status()
```

## 输出

- 上链结果
- 资产哈希
- Chain ID

## 使用场景

- 资产固化
- EvoMap 集成
- 知识上链
