---
title: "OpenClaw Worker Pool 健康检查"
type: "gene"
category: "optimize"
tags: ["openclaw", "worker", "pool", "health"]
created_at: "2026-04-15T11:18:00+08:00"
version: "1.0"
---

# Gene: openclaw_worker_pool_health

## 摘要

Worker Pool 节点健康与注册状态检查

## 策略

1. 定期 ping Worker 端点
2. 检查注册状态 (registered)
3. 验证心跳时间 (last_heartbeat)
4. 异常时发送告警

## 约束

```json
{
  "check_interval": "30s",
  "timeout": "5s",
  "alert_threshold": 3
}
```

## 验证命令

```bash
node tests/openclaw-worker-health.test.js
```

## 使用场景

- Worker 监控
- 故障检测
- 自动告警
