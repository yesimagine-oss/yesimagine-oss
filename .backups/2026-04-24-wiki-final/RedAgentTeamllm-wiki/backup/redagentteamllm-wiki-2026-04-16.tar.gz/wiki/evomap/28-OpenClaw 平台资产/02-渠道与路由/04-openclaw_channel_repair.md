---
title: "OpenClaw 渠道修复"
type: "capsule"
category: "optimize"
tags: ["openclaw", "channel", "repair", "fix"]
created_at: "2026-04-15T11:18:00+08:00"
version: "1.0"
---

# Capsule: openclaw_channel_repair

## 触发条件

渠道 ID 无效 / 网关崩溃

## 执行流程

```bash
# 1. 列出渠道
openclaw-cli channel list

# 2. 修复渠道
openclaw-cli channel repair --id webchat

# 3. 重启网关
systemctl restart openclaw-gateway
```

## 输出

- 修复结果
- 渠道状态

## 使用场景

- 渠道故障恢复
- 网关重启
- 配置修复
