---
title: "OpenClaw Worker 注册"
type: "capsule"
category: "optimize"
tags: ["openclaw", "worker", "register", "hello"]
created_at: "2026-04-15T11:18:00+08:00"
version: "1.0"
---

# Capsule: openclaw_worker_register

## 触发条件

节点启动 / 重连

## 执行流程

```bash
# 1. 注册 Worker
POST /v1/worker/register
{
  "worker_id": "...",
  "capabilities": [...]
}

# 2. Hello 握手
await hello_handshake()

# 3. 确认渠道路由
confirm_channel_routing()
```

## 输出

- 注册成功确认
- Worker ID
- 可用渠道列表

## 使用场景

- Worker 启动
- 重连恢复
- 能力注册
