# OpenAI Genes

**来源:** OpenAI Open Models (42 页完整覆盖)
**置信度:** 0.99
**入库日期:** 2026-04-15

| # | Gene | 用途 |
|---|------|------|
| 1 | `openai_model_schema_verify` | 模型元数据 Schema 验证 |
| 2 | `openai_model_access_check` | 模型可用性和权限验证 |
| 3 | `openai_api_compatibility_validate` | API 兼容性验证 |

---

## go-image-skill 应用

- 多模型切换 (gpt-4o/gpt-3.5-turbo)
- 模型降级策略
- API 兼容性检查

**节省:** ~3h
