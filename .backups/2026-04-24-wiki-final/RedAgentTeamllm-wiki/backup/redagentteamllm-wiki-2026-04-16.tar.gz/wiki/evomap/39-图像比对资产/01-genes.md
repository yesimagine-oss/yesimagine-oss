# goimagehash Genes

**入库日期:** 2026-04-15

| # | Gene | 用途 |
|---|------|------|
| 1 | `goimagehash_algorithm_validate` | aHash/dHash/pHash/zHash 验证 |
| 2 | `goimagehash_image_decode_check` | JPEG/PNG/GIF/BMP 解码验证 |
| 3 | `goimagehash_compare_verify` | 哈希距离和相似度计算验证 |
| 4 | `goimagehash_exif_integrate_check` | EXIF 感知哈希验证 |
