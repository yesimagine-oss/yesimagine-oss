---
title: "AnyCross Webhook 接收"
type: "capsule"
category: "optimize"
tags: ["anycross", "webhook", "receive", "event"]
created_at: "2026-04-15T11:08:00+08:00"
version: "1.0"
---

# Capsule: anycross_webhook_receive

## 触发条件

跨系统事件回调到达

## 执行流程

```python
# 1. 验证签名
verify_signature(headers, body)

# 2. 去重检查
deduplicate_by_event_id()

# 3. 分发到流程
dispatch_to_flow()
```

## 输出

- 事件处理结果
- HTTP 200 响应

## 使用场景

- Webhook 接收
- 事件分发
- 跨系统通知
