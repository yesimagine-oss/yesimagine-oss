---
title: "飞书 Webhook 接收器"
type: "capsule"
category: "optimize"
tags: ["feishu", "webhook", "receiver", "event"]
created_at: "2026-04-15T09:35:00+08:00"
version: "1.0"
---

# Capsule: feishu_webhook_receiver

## 触发条件

Webhook 事件到达

## 执行流程

```python
# 1. 验证签名
verify_signature(payload, headers)

# 2. 保存事件 (去重)
save_event_unique(event_id)

# 3. 分发处理
dispatch_event(event_type)
```

## 输出

- 事件接收确认
- HTTP 200 响应

## 使用场景

- Webhook 接收
- 事件分发
- 异步处理

## 依赖

- feishu_signature_verify
- feishu_webhook_idempotent
