---
title: "AnyCross 连接器健康检查"
type: "gene"
category: "optimize"
tags: ["anycross", "connector", "health", "check"]
created_at: "2026-04-15T11:08:00+08:00"
version: "1.0"
---

# Gene: anycross_connector_health

## 摘要

连接器可用性与健康检查

## 策略

1. 定期 ping 连接器端点
2. 检查响应时间和状态码
3. 验证认证凭证有效性
4. 异常时发送告警

## 约束

```json
{
  "check_interval": "60s",
  "timeout": "5s",
  "alert_threshold": 3
}
```

## 验证命令

```bash
node tests/anycross-connector-health.test.js
```

## 使用场景

- 连接器监控
- 故障检测
- 自动告警
