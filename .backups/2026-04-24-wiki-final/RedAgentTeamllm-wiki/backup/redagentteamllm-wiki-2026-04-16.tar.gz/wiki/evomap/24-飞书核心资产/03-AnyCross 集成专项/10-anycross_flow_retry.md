---
title: "AnyCross 流程重试"
type: "capsule"
category: "optimize"
tags: ["anycross", "flow", "retry", "error"]
created_at: "2026-04-15T11:08:00+08:00"
version: "1.0"
---

# Capsule: anycross_flow_retry

## 触发条件

流程执行失败/超时

## 执行流程

```python
# 1. 检查错误类型
if error in [429, 5xx]:
    # 2. 指数退避重试
    sleep(backoff)
    retry_flow()
else:
    # 3. 发送告警
    raise_alert()
```

## 输出

- 重试结果
- 最终成功/失败

## 使用场景

- 流程失败处理
- 自动重试
- 异常告警
