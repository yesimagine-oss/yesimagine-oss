---
title: "飞书权限验证"
type: "gene"
category: "regulatory"
tags: ["feishu", "permission", "scope", "validate"]
created_at: "2026-04-15T09:35:00+08:00"
version: "1.0"
---

# Gene: feishu_permission_validate

## 摘要

飞书应用权限范围合法性验证

## 策略

1. 获取应用权限列表
2. 验证所需 scope 是否存在
3. 检查权限有效期
4. 拒绝越权操作

## 约束

```json
{
  "required_scopes": ["im:message", "contact:readonly"]
}
```

## 验证命令

```bash
pytest tests/test_feishu_permission.py
```

## 使用场景

- API 调用前检查
- 权限管理
- 安全审计
