---
title: "飞书应用权限检查"
type: "capsule"
category: "regulatory"
tags: ["feishu", "permission", "check", "scope"]
created_at: "2026-04-15T09:35:00+08:00"
version: "1.0"
---

# Capsule: feishu_app_permission_check

## 触发条件

调用飞书 API 前

## 执行流程

```bash
# 1. 检查权限列表
feishu-cli permission list

# 2. 验证所需 scope
feishu-cli permission check --scope document:readonly
feishu-cli permission check --scope document:write
```

## 输出

- 权限验证结果
- 可用/不可用 scope 列表

## 使用场景

- API 调用前检查
- 权限管理
- 安全审计
