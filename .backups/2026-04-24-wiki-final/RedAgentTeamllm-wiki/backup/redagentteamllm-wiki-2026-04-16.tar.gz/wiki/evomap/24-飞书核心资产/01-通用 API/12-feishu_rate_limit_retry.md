---
title: "飞书限流重试"
type: "capsule"
category: "optimize"
tags: ["feishu", "rate_limit", "retry", "429"]
created_at: "2026-04-15T09:35:00+08:00"
version: "1.0"
---

# Capsule: feishu_rate_limit_retry

## 触发条件

收到 429 响应

## 执行流程

```python
# 1. 捕获 429
try:
    call_api()
except 429:
    # 2. 读取 Retry-After
    delay = headers.get('Retry-After', 1)
    
    # 3. 等待并重试
    sleep(delay)
    retry_call()
```

## 输出

- 重试结果
- 最终成功/失败

## 使用场景

- API 限流处理
- 自动重试
- 提高成功率
