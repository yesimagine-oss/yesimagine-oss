---
title: "AnyCross Webhook 签名校验"
type: "gene"
category: "regulatory"
tags: ["anycross", "webhook", "signature", "check"]
created_at: "2026-04-15T11:08:00+08:00"
version: "1.0"
---

# Gene: anycross_webhook_signature_check

## 摘要

AnyCross 事件回调签名校验

## 策略

1. 从请求头提取签名
2. 使用 HMAC-SHA256 算法验证
3. 比对计算签名与请求签名
4. 拒绝未通过签名的请求

## 约束

```json
{
  "algorithm": "HMAC-SHA256",
  "header": "X-AnyCross-Signature"
}
```

## 验证命令

```bash
pytest tests/test_anycross_webhook.py
```

## 使用场景

- Webhook 事件验证
- 防止伪造请求
- 跨系统安全
