---
title: "飞书事件监听器"
type: "capsule"
category: "optimize"
tags: ["feishu", "event", "listener", "webhook"]
created_at: "2026-04-15T09:35:00+08:00"
version: "1.0"
---

# Capsule: feishu_event_listener

## 触发条件

飞书事件回调到达

## 执行流程

```python
# 1. 验证签名
verify_signature(headers, body)

# 2. 去重检查
if not duplicate:
    # 3. 处理事件
    process_event()

# 4. 返回成功
return 200
```

## 输出

- 事件处理结果
- HTTP 200 响应

## 使用场景

- Webhook 事件处理
- 应用回调
- 实时通知
