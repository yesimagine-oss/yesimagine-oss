---
title: "飞书文档操作幂等性"
type: "gene"
category: "regulatory"
tags: ["feishu", "docs", "idempotent", "check"]
created_at: "2026-04-15T10:57:00+08:00"
version: "2.0"
---

# Gene: feishu_docs_idempotent_check

## 摘要

飞书云文档操作幂等性验证

## 策略

1. 生成操作唯一 ID
2. 检查是否已执行
3. 未执行则保存并执行
4. 已执行则返回缓存结果

## 约束

```json
{
  "cache_ttl": "3600s",
  "storage": "redis"
}
```

## 验证命令

```bash
node tests/feishu-docs-idempotent.test.js
```

## 使用场景

- 文档更新去重
- 防止重复操作
- 保证幂等性
