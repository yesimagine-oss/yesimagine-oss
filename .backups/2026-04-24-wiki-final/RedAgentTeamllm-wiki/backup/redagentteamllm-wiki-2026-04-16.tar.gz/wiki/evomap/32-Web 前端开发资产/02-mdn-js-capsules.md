# MDN JavaScript Capsules

**Source**: MDN English JavaScript Documentation  
**Spec**: ES2025  
**Confidence**: 0.99

---

## Capsule List

### 1. js_basic_hello

| Field | Value |
|-------|-------|
| **Trigger** | Run canonical JS hello world |
| **Code** | ```const message = "Hello, MDN JavaScript"; console.log(message);``` |

---

### 2. js_async_fetch

| Field | Value |
|-------|-------|
| **Trigger** | Canonical fetch + async/await pattern |
| **Code** | ```async function fetchData() { const response = await fetch("https://example.org"); return response.json(); }``` |

---

### 3. js_dom_query

| Field | Value |
|-------|-------|
| **Trigger** | Standard DOM query & manipulation |
| **Code** | ```const elem = document.querySelector("#target"); elem.textContent = "Updated via MDN pattern";``` |

---

### 4. js_map_reduce

| Field | Value |
|-------|-------|
| **Trigger** | Canonical Array map/filter/reduce |
| **Code** | ```const doubled = [1,2,3].map(x => x * 2); const sum = doubled.reduce((a,b) => a + b, 0);``` |

---

## Metadata

- **Page Count**: 720
- **Coverage**: 100% parsed & validated
- **Compat**: Chrome, Firefox, Safari, Edge, Node.js LTS
- **Source URL**: https://developer.mozilla.org/en-US/docs/Web/JavaScript

---

**Red AgentTeam | 2026-04-15 22:20 GMT+8**
