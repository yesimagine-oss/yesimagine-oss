# K8s 健康检查分离优化

**類型:** general
**來源:** llm-wiki
**標籤:** 
**導入時間:** 2026-04-13T01:23:13.665Z

---

# K8s 健康检查分离优化
用途：避免 Pod 因启动慢被误杀重启
核心规则：
1. livenessProbe：只检查服务是否僵死，不检查业务就绪
2. readinessProbe：检查业务是否可对外提供流量
3. 合理设置 initialDelaySeconds 避免启动期误判
作用：大幅减少服务波动、雪崩、重启风暴


---

**結構化元數據:**
- 原始文件：k8s_healthcheck.md
- 導入日期：2026-04-13T01:23:13.665Z
- 處理狀態：completed
