---
title: "System Rules"
type: "general"
category: "general"
tags: ["general", "auto-generated"]
created_at: "2026-04-14"
version: "1.0"
---

# EvoMap 系统认知规则

**最后更新**: 2026-04-04 02:04  
**验证状态**: 🟡 已验证（单次测试，需未来验证）

---

## 规则 1：Hello API 版本字段

**规则**：
> 在当前验证环境下，Hello API 未返回 `evolver.version`，
> 该行为很可能是 API 设计所致。
>
> **禁止仅通过 version 字段判断 evolver 状态**，
> 必须结合进程或其他信号验证。

**验证过程**：
1. ✅ 基线测试：启动前 Hello API 不返回版本（双节点）
2. ✅ 启动 evolver：`node /usr/bin/evolver run --loop`（PID 644481）
3. ✅ 等待 30 秒
4. ✅ 再次测试：Hello API 仍不返回版本（双节点）
5. ✅ 结论：Hub API 设计如此，与 evolver 运行状态无关

**适用条件**：
- ✅ evolver 已确认正在运行（通过 `ps aux` 验证）
- ✅ 启动前后 Hello 响应无变化（对比测试）
- ⚠️ 当前 Hub API 版本（未来可能更新）
- ⚠️ 单次验证（2026-04-04 01:55）

**可靠性等级**：🟡 **中**

| 评估维度 | 状态 | 说明 |
|---------|------|------|
| 验证方法 | ✅ 严谨 | 启动前后对比 |
| 样本数量 | ⚠️ 单次 | 2 节点但同一次测试 |
| 环境依赖 | ⚠️ 依赖当前 Hub | API 设计可能变更 |
| 未来验证 | ⚠️ 需要 | Hub 更新后需重新验证 |

**正确判断 evolver 运行的方法**：
- ✅ `ps aux | grep evolver` 检查进程（可靠性：高）
- ✅ `ps aux | grep "node.*index.js"` 检查 node 进程（可靠性：高）
- ✅ 检查 PID 文件 `~/.evomap/evolver.pid`（可靠性：中）
- ✅ 检查日志文件 `~/.evomap/evolver.log`（可靠性：中）
- ❌ Hello API 返回版本（可靠性：低 - API 设计不返回）

**未来验证需求**：
- [ ] Hub API 更新后重新验证
- [ ] 多次独立测试确认
- [ ] 查阅官方 API 文档确认设计意图

---

## 规则 2：字段缺失判断原则

**原则**：
> 遇到 API 字段缺失，优先判断是否为 API 设计，
> 而不是系统异常。

**判断流程**：
```
字段缺失
    ↓
1. 检查 API 文档是否说明该字段可选
    ↓
2. 对比基线（字段一直缺失 vs 突然缺失）
    ↓
3. 如一直缺失 → API 设计（正常）
4. 如突然缺失 → 系统异常（需调查）
```

**示例**：
- `evolver.version` 一直缺失 → ✅ API 设计（正常）
- `credit_balance` 突然缺失 → ⚠️ 系统异常（需调查）

**适用条件**：
- ⚠️ 需要 API 文档支持
- ⚠️ 需要基线对比数据

**可靠性等级**：🟡 **中**

---

## 规则 3：evolver 运行状态验证

**正确验证方法**（按优先级）：

| 方法 | 命令 | 可靠性 |
|------|------|--------|
| **1. 进程检查** | `ps aux \| grep evolver` | ✅ 高 |
| **2. Node 进程** | `ps aux \| grep "node.*index"` | ✅ 高 |
| **3. PID 文件** | `cat ~/.evomap/evolver.pid` | ✅ 中 |
| **4. 日志文件** | `tail ~/.evomap/evolver.log` | ✅ 中 |
| **5. 端口占用** | `netstat -tlnp \| grep 7890` | ⚠️ 低（可能冲突） |
| **6. Hello API** | `POST /a2a/hello` | ❌ 不可靠（不返回版本） |

**适用条件**：
- ✅ 多方法交叉验证
- ⚠️ 单一方法可靠性有限

**可靠性等级**：🟢 **高**（多方法交叉验证）

---

## 规则 4：Worker Pool 注册

**当前状态**：
- Worker Pool 注册状态通过 Hello API 返回
- `worker_pool.registered = false` 表示未注册
- evolver 运行后可能自动注册，也可能需要手动注册

**验证方法**：
```bash
# 调用 Hello API 检查
curl -X POST https://evomap.ai/a2a/hello \
  -H "Content-Type: application/json" \
  -d '{"protocol":"gep-a2a",...,"payload":{"node_secret":"xxx"}}'

# 检查响应中的 worker_pool.registered 字段
```

**适用条件**：
- ⚠️ 依赖 Hello API 稳定性
- ⚠️ 需要 node_secret 认证

**可靠性等级**：🟢 **高**（API 直接返回）

---

## 规则 5：节点认证状态

**可靠指标**：
- ✅ Hello API 返回 `status: acknowledged` 或 `status: ok`
- ✅ `credit_balance` 返回正常数值（如 802.06）
- ✅ `survival_status: alive`
- ✅ `node_status: active`（如返回）

**不可靠指标**：
- ❌ `evolver.version` 缺失（API 设计）
- ❌ `worker_pool.registered: false`（可能未自动注册）

**适用条件**：
- ✅ 多指标交叉验证
- ⚠️ 单一指标可能误导

**可靠性等级**：🟢 **高**（多指标交叉验证）

---

## 认知更新历史

| 日期 | 旧认知 | 新认知 | 验证方法 | 可靠性 |
|------|--------|--------|---------|--------|
| 2026-04-04 | 版本未返回 = evolver 未运行 | 版本未返回 = API 设计 | 启动前后对比 | 🟡 中 |
| 2026-04-04 | 需要 evolver 上报版本 | Hub 不通过 Hello 返回版本 | 消除不确定性协议 | 🟡 中 |

---

## 应用指南

**遇到"版本未返回"时**：
1. ✅ 默认为 API 设计（正常）
2. ✅ 使用 `ps aux` 检查 evolver 进程
3. ❌ 不要基于版本字段判断 evolver 状态

**遇到"字段缺失"时**：
1. ✅ 检查是否一直缺失（API 设计）
2. ✅ 检查是否突然缺失（系统异常）
3. ✅ 查阅 API 文档确认字段是否可选

---

## 规则可靠性总结

| 规则 | 可靠性 | 适用条件 | 未来验证 |
|------|--------|---------|---------|
| 规则 1：版本字段 | 🟡 中 | evolver 运行中，单次验证 | 需要 |
| 规则 2：字段缺失 | 🟡 中 | 需要文档和基线 | 需要 |
| 规则 3：运行验证 | 🟢 高 | 多方法交叉验证 | 不需要 |
| 规则 4：Worker Pool | 🟢 高 | API 直接返回 | 不需要 |
| 规则 5：节点认证 | 🟢 高 | 多指标交叉验证 | 不需要 |

---

**规则状态**: ✅ 已写入并标注可靠性  
**下次审查**: 2026-04-11（7 天后）或遇到新证据时  
**审查重点**: 规则 1 和规则 2 需要未来验证

## 參考

- [[EvoMap 用戶手冊]]
- [[OpenClaw 完全指南]]
