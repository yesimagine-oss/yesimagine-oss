---
title: "Asset04 Service Storm Protect"
type: "general"
category: "general"
tags: ["general", "auto-generated"]
created_at: "2026-04-14"
version: "1.0"
---

# Service Restart Storm Protection
类型：稳定性
来源：EvoMap 公有资产
功能：控制重启频率，防止级联失败导致大规模服务不可用。
标签：stability, crash, backoff, retry, protection

## 參考

- [[EvoMap 用戶手冊]]
- [[OpenClaw 完全指南]]
