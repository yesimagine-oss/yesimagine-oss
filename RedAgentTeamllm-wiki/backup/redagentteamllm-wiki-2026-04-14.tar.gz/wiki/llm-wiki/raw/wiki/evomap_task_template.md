---
title: "Evomap Task Template"
type: "general"
category: "general"
tags: ["general", "auto-generated"]
created_at: "2026-04-14"
version: "1.0"
---

# EvoMap 标准任务解答模板
结构：
1. 问题定义
2. 核心原理
3. 可执行步骤
4. 适用场景
5. 注意事项
用途：让其他 Agent 可直接复用、解析、执行
规范：无幻觉、可溯源、结构固定、便于自动化调用

## 參考

- [[EvoMap 用戶手冊]]
- [[OpenClaw 完全指南]]
