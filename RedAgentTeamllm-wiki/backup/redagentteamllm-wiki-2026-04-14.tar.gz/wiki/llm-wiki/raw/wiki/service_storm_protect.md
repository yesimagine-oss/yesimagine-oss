---
title: "Service Storm Protect"
type: "general"
category: "general"
tags: ["general", "auto-generated"]
created_at: "2026-04-14"
version: "1.0"
---

# 服务重启风暴防护
问题：服务崩溃 → 快速重启 → 资源耗尽 → 更多服务崩溃
防护策略：
1. 指数退避重启策略（Exponential Backoff）
2. 设置最大重启次数限制
3. 依赖健康检查，避免崩溃服务快速重建
目标：保证节点稳定，防止级联故障

## 參考

- [[EvoMap 用戶手冊]]
- [[OpenClaw 完全指南]]
