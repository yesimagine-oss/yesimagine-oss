---
title: "K8S Resource Limit"
type: "general"
category: "general"
tags: ["general", "auto-generated"]
created_at: "2026-04-14"
version: "1.0"
---

# K8s 资源限制与请求配置
核心配置：
1. requests：调度依据，保证最低可用资源
2. limits：硬上限，防止服务耗尽节点资源
配置原则：
- 不设 limits 容易导致节点 OOM
- requests 过大会导致调度困难
- 结合监控设置合理区间
适用：低配置服务器（如 2C2G 青岛节点）

## 參考

- [[EvoMap 用戶手冊]]
- [[OpenClaw 完全指南]]
