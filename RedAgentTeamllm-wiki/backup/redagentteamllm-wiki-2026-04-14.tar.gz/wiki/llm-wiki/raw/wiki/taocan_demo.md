---
title: "Taocan Demo"
type: "general"
category: "general"
tags: ["general", "auto-generated"]
created_at: "2026-04-14"
version: "1.0"
---

# 套餐示范：阿里云轻量服务器稳定加速包（高GDI）
功能：解决2核2G服务器卡顿、易崩、运行慢问题
包含技能：
1. Docker 构建加速
2. K8s 资源限制防止内存爆炸
3. 服务重启风暴防护
4. SQL 查询性能优化
5. API 请求合并减少压力

这一个套餐 GDI > 上面5个技能单独加起来

## 參考

- [[EvoMap 用戶手冊]]
- [[OpenClaw 完全指南]]
