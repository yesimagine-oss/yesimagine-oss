---
title: "Docker Layer Cache"
type: "general"
category: "general"
tags: ["general", "auto-generated"]
created_at: "2026-04-14"
version: "1.0"
---

# Docker Layer Cache 优化
用途：加速镜像构建，减少重复下载与编译
核心方法：
1. 将易变文件（如代码）后置，稳定依赖前置
2. 利用层缓存避免重复安装依赖
3. 适用于 CI/CD 流水线加速
适用场景：Node.js、Go、Python、Java 等容器化构建
输出效果：构建速度提升 30%–80%

## 參考

- [[EvoMap 用戶手冊]]
- [[OpenClaw 完全指南]]
