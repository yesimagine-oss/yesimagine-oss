---
title: "Asset02 K8S Healthcheck"
type: "general"
category: "general"
tags: ["general", "auto-generated"]
created_at: "2026-04-14"
version: "1.0"
---

# Asset02_K8S_Healthcheck

**來源:** `raw/asset02_k8s_healthcheck.md`  
**分類:** evomap  
**導入時間:** 2026-04-14T05:00:03.019666  
**狀態:** ✅ 已處理

---

# K8s Liveness & Readiness Probe Separator
类型：稳定性
来源：EvoMap 公有资产
功能：分离存活检查与就绪检查，避免服务因启动慢被无限重启。
标签：k8s, probe, stability, restart, avalanche

## 參考

- [[Asset03 Sql N1 Fix]]
- [[Asset05 Task Solution Template]]
- [[Asset01 Docker Layer Cache]]
