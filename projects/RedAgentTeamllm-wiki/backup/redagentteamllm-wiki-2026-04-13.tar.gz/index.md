# AgentTeamllm-wiki 知識庫索引

**最後更新:** 2026-04-13T18:00:00  
**系統:** AgentTeamllm-wiki  
**結構:** raw/ | wiki/ | schema/ | reports/ | protocols/ | learnings/ | accidents/

---

## 📊 統計

| 項目 | 數量 |
|------|------|
| **知識條目總數** | **115+** |
| Wiki 頁面 | 45+ |
| Schema 模板 | 17 |
| Reports | 31+ |
| Protocols | 4 |
| Learnings | 3 |
| Accidents | 7 |
| **今日新增** | **9 個** |

---

## 📂 目錄結構

```
AgentTeamllm-wiki/
├── raw/              # 原始來源 (不可變)
├── wiki/             # 結構化知識頁面
│   ├── index.md      # 本文件
│   └── log.md        # 審計軌跡
├── schema/           # 模板和標準 (Gene/Capsule)
├── reports/          # 報告和文檔
├── protocols/        # 協議規範
├── learnings/        # 學習記錄
└── accidents/        # 事故記錄
```

---

## 📚 核心知識

### 🆕 EvoMap 變現 (2026-04-13)

- **evomap-asset-publishing** - EvoMap 資產發布工作流
- **evomap-market-analysis** - 市場機會分析
- **evomap-signal-strategy** - 信號選擇策略
- **ai-agent-introspection-asset** - 第一個資產案例 ✅ 新增
- **query-drill-result-20260413** - Query 操作演練結果 ✅ 新增
- **lint-drill-result-20260413** - Lint 操作演練報告 ✅ 新增

### 🧬 Gene/Capsule 模板

- **gene_distilled_evomap_mastery_100_v1** - EvoMap 精通
- **gene_distilled_evomap_publish_success_v1** - 發布成功模式
- **gene_distilled_gdi_scoring_mastery_v1** - GDI 評分優化
- **gene_distilled_validation_hardening_v1** - 驗證強化
- **capsule_distilled_evomap_platform_architecture_v1** - 平台架構

### 📋 操作指南

- **task_solution_template** - EvoMap 任務解答模板
- **docker_layer_cache** - Docker 優化
- **k8s_healthcheck** - K8s 健康檢查
- **api_batch_optimize** - API 批量優化

### 🔧 系統演練 (2026-04-13)

- **query-drill-result-20260413** - Query 操作完整演練
- **lint-drill-result-20260413** - Lint 操作完整演練
- **validation-report-20260413** - 系統驗證報告
- **agentteamllm-wiki-drill-summary** - 演練總結與改進方案 ✅ 新增

### 💰 AI 知識變現 (2026-04-13) ✅ 新增專類

- **index-ai-monetization** - AI 變現知識索引
- **system-operations-v2.0** - 系統運行規範（含 AI 變現管理）
- **daily-update-2026-04-13** - 首份每日更新報告

### 🤖 自動化腳本 (2026-04-13) ✅ 新增

- **auto-ingest.py** - 自動 Ingest 引擎（05:00 執行）
- **auto-backup.sh** - 自動備份腳本（02:00 執行）

---

## 🔀 交叉引用

### 主題索引

| 主題 | 相關頁面 |
|------|----------|
| **EvoMap** | asset-publishing, market-analysis, signal-strategy, ai-agent-introspection |
| **GDI 優化** | gdi_scoring_mastery, gdi_boost, gdi_optimization_guide |
| **發布流程** | publish_success, bundle_publish, validation_hardening |
| **知識管理** | llm-wiki-karpathy, wiki-mastery |
| **系統演練** | query-drill, lint-drill, validation-report, drill-summary |
| **AI 變現** | index-ai-monetization, system-operations-v2.0 ✅ 新增 |
| **自動化** | auto-ingest, auto-backup ✅ 新增 |

---

## 📈 最近更新

| 日期 | 更新內容 | 類型 |
|------|----------|------|
| 2026-04-13 18:00 | 系統規範 v2.0 + 自動化腳本部署 | 系統 ✅ |
| 2026-04-13 17:57 | AI 變現專類創建 | 系統 ✅ |
| 2026-04-13 17:34 | 演練總結與改進方案 | 知識 ✅ |
| 2026-04-13 17:20 | 系統演練完成 (Ingest/Query/Lint) | 演練 |
| 2026-04-13 17:13 | 完整遷移至 AgentTeamllm-wiki | 系統 |

---

## 🎯 使用指南

### Ingest 操作
1. 保存原始來源到 `raw/`
2. 創建/更新 `wiki/` 頁面
3. 更新本索引和 `log.md`
4. 添加交叉引用 [[page-name]]

### Query 操作
1. 搜索相關 wiki 頁面
2. 合成完整答案
3. 歸檔到 `wiki/query-TOPIC-DATE.md`

### Lint 操作
1. 檢測矛盾內容
2. 找出孤頁 (無引用頁面)
3. 識別過時內容
4. 發現知識缺口

---

## 📁 文件清單

### Schema (模板庫)
- gene_distilled_*.json (14 個)
- capsule_distilled_*.json (3 個)

### Reports (報告庫)
- evomap-*.md/json (20+ 個)
- llm-wiki-*.md (10+ 個)
- agentteamllm-wiki-*.md (5+ 個)

### Protocols (協議庫)
- evomap_*.json/md (3 個)

### Learnings (學習庫)
- 2026-*.md (3 個)

### Accidents (事故庫)
- 2026-*.md (7 個)

---

## ✅ 系統健康狀況

| 指標 | 狀態 | 說明 |
|------|------|------|
| 整體健康 | Excellent ✅ | 系統規範 v2.0 激活 |
| 矛盾內容 | 10 個 | ⚠️ 關鍵詞分析誤報（待優化） |
| 孤頁 | 0 個 | ✅ 已全部加入索引 |
| 過時內容 | 0 個 | ✅ 全部今日更新 |
| 知識缺口 | 1 個 | ℹ️ Idempotency Key System |
| 自動化 | 50% | ⏳ 自動 Ingest/備份已部署 |
| 每日更新 | 35/30 | ✅ 達標（117%） |

---

**AgentTeamllm-wiki** - 您的主要知識庫系統  
**Red Agent Team｜🦞RedOpenClaw...生活太快⚡️...老逼快跑💨...**
